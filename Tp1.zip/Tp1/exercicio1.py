# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 20:58:03 2017

@author: joao
"""

#1. Abra o ficheiro com a imagem "lenac.tif"e apresente a imagem. Verifique para que servem os métodos "dtype"e
#"shape":

import cv2
import numpy as np
import matplotlib.pyplot as plt
x_img = cv2.imread("lenac.tif")
cv2.imshow('Original Image',x_img)
print x_img.dtype   #tipo da variavel e codificação (uint8)
print x_img.shape   #mostra o numero de (linhas, colunhas, planos)
cv2.waitKey(10) #podera ter que se mudar o valor 0
cv2.destroyAllWindows()



#### aulaaaaa ######
I = cv2.imread("lenac.tif")
cv2.namedWindow('Lena1',1)
cv2.imshow('Lena1',I)
while True:
    cvKey=cv2.waitKey(10)
    if cvKey==27:
        cv2.destroyAllWindows()
        break;

#2. Grave a mesma imagem, mas agora em formato "JPEG"com diferentes qualidades. Verifique visualmente a
#qualidade das imagens assim como o tamanho do ficheiro. Calcule a taxa de compressão, a SNR e a PSNR.

cv2.imwrite('file1.jpg', x_img, (cv2.IMWRITE_JPEG_QUALITY, 80))

img1= cv2.imread("file1.jpg")
print img1.shape

        
        
cv2.imwrite('file2.jpg', x_img, (cv2.IMWRITE_JPEG_QUALITY, 10))

def SNR(img_original, img_transformada):
    #colocar um for
    Pplano0 = sum(img1[::0]**2)/len(img1[::0])
    Pplano1 = sum(img1[::1]**2)/len(img1[::1])
    Pplano2 = sum(img1[::2]**2)/len(img1[::2])
    nPixeis = 
    Pimagem = (Pplano0 + Pplano1 + Pplano2)/nPixeis

    erro=  x_img - img1
    #colocar um for
    PEplano0 = sum(erro[::0]**2)/len(erro[::0])
    PEplano1 = sum(erro[::1]**2)/len(erro[::1])
    PEplano2 = sum(erro[::2]**2)/len(erro[::2])
    nPixeis = 
    Perro = (PEplano0 + PEplano1 + PEplano2)/nPixeis
    SNR = 10*m.log10( Pimagem/Perro )   #SNR pratica
    
    return SNR
#3. Converta a imagem para níveis de cinzento, usando o método "cvtColor"e grave a imagem. Este método aplica
#a transformação Y = R299=1000+G587=1000+B114=1000, justifique a utilização desta equação. Verifique
#também o tamanho do ficheiro e compare-o com o ficheiro original.

x_img_g = cv2.cvtColor(x_img,cv2.COLOR_BGR2GRAY)
cv2.imshow('Gray Image', x_img_g)
cv2.imwrite('file3.bmp', x_img_g)

#4. Apresente o histograma da imagem em tons de cizento, verifique quantos níveis de cizento tem a imagem.

plt.hist(x_img_g.ravel(),256,[0,256])

#5. Nos próximos trabalhos será necessário realizar operações com os valores de cada pixel. Para este efeito podese
#transformar a imagem para um array. O código seguinte representa o pixel mais significante da imagem.
#Apresente oito imagens, cada uma com o valor de cada bit para todos os pixeis.

#ir buscar o bit mais significativo e representar a imagem, e semore assim para todos os bit (shift)
y = x_img_g > 128
cv2.imshow('BW',y*1.0)

#6. Grave uma imagem que contém apenas a informação dos 4 bits mais significantes da imagem.

#y= . . .
cv2.imwrite('lena_4 .bmp',y)


#7 -> criar um array a branco arr=np.ones((4,4))*255
#  -> calcular o angulo com alpha=np.arctan(y/x.)*180/np.pi 
#  -> 
#  -> 



